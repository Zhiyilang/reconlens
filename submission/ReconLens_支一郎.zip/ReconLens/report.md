# Reconciliation report

| Metric | Value |
|---|---|
| Bank entries | 8 |
| Ledger entries | 9 |
| Matched pairs | 5 |
| Discrepancies | 6 |
| Explained | 4 (66.7%) |
| Unexplained | 2 |

## Discrepancies by cause

| Cause | Count |
|---|---|
| DATE_MISMATCH | 2 |
| FEE_DEDUCTION | 2 |
| UNEXPLAINED | 2 |

## Detail

### DATE_MISMATCH (`bank`, confidence 0.63)
- `b07` 2026-09-15 750.00 — payout

**Evidence**

- amounts are identical (75000)  _(entry.amount, w=1.0)_
- dates differ by 15 days, beyond the 3-day window  _(matcher.day_gap, w=1.0)_
- descriptions 100% similar  _(explain.similarity, w=0.7)_

**Counter-evidence**

- two unrelated payments of the same size in the same period are possible  _(domain, w=0.6)_

> typical of settlement lag or a cut-off at period end

### DATE_MISMATCH (`ledger`, confidence 0.63)
- `l08` 2026-09-30 750.00 — payout

**Evidence**

- amounts are identical (75000)  _(entry.amount, w=1.0)_
- dates differ by 15 days, beyond the 3-day window  _(matcher.day_gap, w=1.0)_
- descriptions 100% similar  _(explain.similarity, w=0.7)_

**Counter-evidence**

- two unrelated payments of the same size in the same period are possible  _(domain, w=0.6)_

> typical of settlement lag or a cut-off at period end

### FEE_DEDUCTION (`bank`, confidence 0.53)
- `b02` 2026-09-03 475.00 — INV-1002 payment

**Evidence**

- shortfall of 500 minor units (1.053% of the entry)  _(explain.delta, w=1.0)_
- shortfall is within the fee-shaped band (<= 2%)  _(explain.FEE_MAX_RATIO, w=0.8)_

**Counter-evidence**

- a small shortfall can also be a data-entry or rounding error  _(domain, w=0.6)_

> confirm against the fee schedule

### FEE_DEDUCTION (`ledger`, confidence 0.53)
- `l02` 2026-09-03 480.00 — INV-1002 payment

**Evidence**

- shortfall of 500 minor units (1.042% of the entry)  _(explain.delta, w=1.0)_
- shortfall is within the fee-shaped band (<= 2%)  _(explain.FEE_MAX_RATIO, w=0.8)_

**Counter-evidence**

- a small shortfall can also be a data-entry or rounding error  _(domain, w=0.6)_

> confirm against the fee schedule

### UNEXPLAINED (`bank`, confidence 0.20)
- `b08` 2026-09-18 330.00 — refund

**Evidence**

- nearest residual differs by 15000 minor units and 15 days  _(explain.nearest, w=0.5)_

**Counter-evidence**

- no amount, date or reference agreement with any residual  _(explain.search, w=1.0)_

> no supported cause — left for a human on purpose

### UNEXPLAINED (`ledger`, confidence 0.20)
- `l09` 2026-09-28 666.66 — mystery item

**Evidence**

- nearest residual differs by 8334 minor units and 13 days  _(explain.nearest, w=0.5)_

**Counter-evidence**

- no amount, date or reference agreement with any residual  _(explain.search, w=1.0)_

> no supported cause — left for a human on purpose

